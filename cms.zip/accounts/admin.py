from django.contrib import admin
from accounts.models import User
from posts.models import *
try:
    admin.site.register(User)
    admin.site.register(Category)
    admin.site.register(Posts)
    admin.site.register(Banners)
except (AttributeError) as e:
    print (e)
    pass