DATABASES = {

    'default': {

        'ENGINE': 'django.db.backends.mysql',

        'NAME': 'cms',

        'USER': 'root',

        'PASSWORD': 'password',

        'HOST': '127.0.0.1',

        'PORT': '',

    }

}
SITE_ID = 2

MEDIA_ROOT = "/home/santhosh/cms/media"
